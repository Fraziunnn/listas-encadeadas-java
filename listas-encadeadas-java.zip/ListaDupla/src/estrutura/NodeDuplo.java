package estrutura;

public class NodeDuplo {
    int data;
    NodeDuplo next;
    NodeDuplo prev;

    public NodeDuplo(int data) {
        this.data = data;
        this.next = null;
        this.prev = null;
    }
}
