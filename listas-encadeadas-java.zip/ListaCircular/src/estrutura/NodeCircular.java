package estrutura;

public class NodeCircular {
    int data;
    NodeCircular next;

    public NodeCircular(int data) {
        this.data = data;
        this.next = null;
    }
}

